#ifndef MISC_H
#define MISC_H

int body();  
int initialize();
help();

#endif