mount -o loop mtximage /mnt










